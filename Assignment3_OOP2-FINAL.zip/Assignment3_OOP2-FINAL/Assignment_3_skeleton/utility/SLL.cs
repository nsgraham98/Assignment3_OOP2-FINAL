﻿using Assignment_3_skeleton.utility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3_skeleton
{
    public class SLL : LinkedListADT
    {
        public Node head; // first node in sll list

        public Node tail; // last node in list
        //int size = 0;

        public bool Empty
        {
            get { return head != null; }
        }

        public Node Head
        {
            get
            {
                return head;
            }
            set => head = value;
        }
        public Node Tail { get => tail; set => tail = value; }
        //public int Size { get => size; set => size = value; }

        public SLL()
        {
            Head = Tail = null; // empty list for tests to work on
        }

        public Node GetHead()
        {
            return head;
        }

        public void Append(Object data)
        {
            Node node = new Node(data);
            if (head == null)
            {
                head = node; // assigns the data to first node if list is empty
            }

            else
            {
                Node current = head;
                while (current.Successor != null) // get to end of the list
                {
                    current = current.Successor;
                }
                current.Successor = node; // assign data to the last node
            }
            //{
            //    Node newNode = new Node(data);

            //    if (IsEmpty())
            //    {
            //        Head = Tail = new Node(data);
            //        return;
            //    }

            //    Tail.Successor = newNode;
            //    Tail = newNode;
            //}

        }

        public void Clear()
        {
            Head = null;
        }

        public bool Contains(Object data)
        {
            //throw new NotImplementedException();
            Node current = Head;
            while (current != null) // while loop to iterate through the list
            {
                if (current.Element == data)
                {
                    return true;
                }
                current = current.Successor;
            }
            return false; // end of the list but item is not found
        }

        public void Delete(int index)
        {
            //throw new NotImplementedException();
            if (index < 0 || Head == null) // is list is empty or index is neg
            {
                throw new ArgumentOutOfRangeException("List is empty or index is negative");
            }
            if (index == 0)
            {
                Head = Head.Successor; // reassign head node to delete
            }

            Node current = Head;
            int counter = 0;
            while (current != null && counter < index - 1) // iterate through the list to just before intended index
            {
                current = current.Successor;
                counter++;
            }

            //check if the next item in list is the end
            if (current == null || current.Successor == null)
            {
                throw new ArgumentOutOfRangeException("Specified index out of range of list");
            }

            current.Successor = current.Successor.Successor; // move the pointer to exclude the object at index
        }

        public int IndexOf(Object data)
        {
            //throw new NotImplementedException();
            Node current = Head;
            int counter = 0;

            while (current != null) // iterate through the list to find a match
            {
                if ((current.Element == data) == true)
                {
                    return counter;
                }

                current = current.Successor;
                counter++;
            }
            counter = -1;
            return counter;
        }

        public void Insert(Object data, int index)
        {
            //throw new NotImplementedException();
            Node current = Head;
            int counter = 0;

            if (index == 0)
            {
                Node newHead = new Node(data);
                newHead.Successor = Head; //old head becomes second in idex
                Head = newHead;
            }

            if (index < 0)
            {
                throw new IndexOutOfRangeException("Index cannot be negative");
            }

            while (current != null && counter < index - 1) // iterate through the list to intended index -1
            {
                current = current.Successor;
                counter++;
            }

            //check if the next item in list is the end
            if (current == null || current.Successor == null)
            {
                throw new ArgumentOutOfRangeException("Specified index out of range of list, cannot insert");
            }

            Node newCurrent = new Node(data);
            newCurrent.Successor = current.Successor; // new node now at specified index
            current.Successor = newCurrent; //intended index -1 has pointer to new node
        }

        public bool IsEmpty()
        {
            //throw new NotImplementedException();
            if (Head == null)
                return true;
            else
                return false;
        }

        public void Prepend(Object data)
        {
            //throw new NotImplementedException();
            Node newHead = new Node(data);
            newHead.Successor = Head; //old head becomes second in idex
            Head = newHead;
        }

        public void Replace(Object data, int index)
        {
            //throw new NotImplementedException();
            Node current = Head;
            int counter = 0;

            if (index == 0)
            {
                Node newHead = new Node(data);
                Head = newHead; // replace old head with new node
            }

            if (index < 0)
            {
                throw new IndexOutOfRangeException("Index cannot be negative");
            }

            //while (current != null && counter < index) // iterate through the list to intended index 
            //{
            //    current = current.Successor;
            //    counter++;
            //}

            while (current != null) // iterate through the list to intended index 
            {
                if (counter == index)
                {
                    current.Element = data;
                    return;
                }
                current = current.Successor;
                counter++;
            }

            //check if the current item in list is the end
            if (current == null)
            {
                throw new ArgumentOutOfRangeException("Specified index out of range of list, cannot replace");
            }

            //Node newCurrent = new Node(data);
            //current = newCurrent; // replace the node
        }

        public object Retrieve(int index)
        {
            //throw new NotImplementedException();
            Node current = Head;
            int counter = 0;

            if (index < 0)
            {
                throw new IndexOutOfRangeException("Index cannot be negative");
            }

            if (index == 0)
            {
                return current.Element;
            }

            while (current != null) // iterate list to specified index
            {
                if (counter == index)
                {
                    return current.Element;
                }

                current = current.Successor;
                counter++;
            }

            // counted beyond the size of the list
            throw new IndexOutOfRangeException("Index is larger than the list");
        }

        public int Size()
        {
            //throw new NotImplementedException();
            Node current = Head;
            int counter = 0;

            //if (current == null) // list is empty
            //{ 
            //    counter = 0;
            //    return counter;
            //}

            while (current != null) // iterate list to count each object
            {
                current = current.Successor;
                counter++;
            }
            return counter;
        }

        public void RemoveHead()
        {
            if (Head == null) // empty list
            {
                throw new InvalidOperationException("The list is currently empty");
            }

            Head = Head.Successor; //assign the second node as the new head
        }

        public void RemoveTail()
        {
            if (Head == null) // empty list
            {
                throw new InvalidOperationException("The list is currently empty");
            }

            Node current = Head;

            while (current.Successor != null && current.Successor.Successor != null) // get to second last node
            {
                current = current.Successor;
            }

            current.Successor = null; // assign current node (second last) as the tail node
        }

        public void serialize(BinaryFormatter bf, List<Node> nodes)
        {
            FileStream str = new FileStream("..\\..\\res\\SLL.bin", FileMode.Create, FileAccess.Write);
            bf.Serialize(str, nodes);
            str.Close();
        }

        public void deserialize(BinaryFormatter bf)
        {
            FileStream str = new FileStream("..\\..\\res\\SLL.bin", FileMode.Open, FileAccess.Read);
            SLL nodes = (SLL)bf.Deserialize(str);

            str.Close();
        }

    }
    //public class SLL : LinkedListADT
    //{
    //    Node head;
    //    Node tail;

    //    public SLL()
    //    {
    //        Head = Tail = null;
    //    }

    //    public Node Head { get => head; set => head = value; }
    //    public Node Tail { get => tail; set => tail = value; }

    //    public void Append(object data)
    //    {
    //        Node newNode = new Node(data);

    //        if (IsEmpty())
    //        {
    //            head = tail = newNode;
    //            return;
    //        }

    //        tail.Next = newNode;
    //        tail = newNode;
    //    }

    //    public void Clear()
    //    {
    //        head = null;
    //    }

    //    public bool Contains(object data)
    //    {
    //        if (IsEmpty())
    //        {  return false; }

    //        Node comparisonNode = Head;
    //        Node targetNode = new Node(data);

    //        do
    //        {
    //            if (comparisonNode.Data.Equals(targetNode.Data))
    //            { 
    //                return true;
    //            }
    //            comparisonNode = comparisonNode.Next;
    //        }
    //        while (comparisonNode.Next != null);

    //        return false;
    //    }

    //    public void Delete(int index)
    //    {
    //        if (IsEmpty()) { return; }
    //        if (index == 0) { head = head.Next; }

    //        int previousNodeIndex = 1;
    //        for (Node tempNode = head; tempNode != null; tempNode = tempNode.Next)
    //        {
    //            if (previousNodeIndex == index)
    //            {
    //                tempNode.Next = tempNode.Next.Next;
    //                return;
    //            }
    //            else { previousNodeIndex++; }
    //        }
    //    }

    //    public int IndexOf(object data)
    //    {
    //        if (IsEmpty()) { throw new Exception("List is empty"); }

    //        int index = 0;
    //        Node targetNode = new Node(data);
    //        Node comparisonNode = head;

    //        do
    //        {
    //            if (comparisonNode.Data.Equals(targetNode.Data))
    //            {
    //                return index;
    //            }
    //            else
    //            {
    //                comparisonNode = comparisonNode.Next;
    //                index++;
    //            }
    //        }
    //        while (comparisonNode.Next != null);

    //        throw new Exception("Item not in List");
    //    }

    //    public void Insert(object data, int index)
    //    {
    //        if (IsEmpty()) { throw new Exception("Invalid index, List is empty"); }
    //        if (index == 0)
    //        {
    //            Prepend(data);
    //        }

    //        int previousNodeIndex = 1;
    //        for (Node tempNode = head; tempNode != null; tempNode = tempNode.Next)
    //        {
    //            if (previousNodeIndex == index)
    //            {
    //                Node newNode = new Node(data, tempNode.Next);
    //                tempNode.Next = newNode;
    //                return;
    //            }
    //            else { previousNodeIndex++; }
    //        }

    //        throw new Exception("Index outside of range");
    //    }


    //    public bool IsEmpty()
    //    {
    //        if (head == null) { 
    //            return true; }
    //        else { 
    //            return false; }
    //    }

    //    public void Prepend(object data)
    //    {
    //        if (IsEmpty())
    //        {
    //            head = tail = new Node(data);
    //            return;
    //        }
    //        Node newNode = new Node(data, head);
    //        head = newNode;
    //    }

    //    public void Replace(object data, int index)
    //    {
    //        if (IsEmpty()) { throw new Exception("Invalid index, List is empty"); }
    //        if (index == 0)
    //        {
    //            Node newNode = new Node(data, head.Next);
    //            head = newNode;
    //        }

    //        int previousNodeIndex = 1;
    //        for (Node tempNode = head; tempNode != null; tempNode = tempNode.Next)
    //        {
    //            if (previousNodeIndex == index)
    //            {
    //                Node newNode = new Node(data, tempNode.Next.Next);
    //                tempNode.Next = newNode;
    //                return;
    //            }
    //            else { previousNodeIndex++; }
    //        }

    //        throw new Exception("Index outside of range");
    //    }

    //    public object Retrieve(int index)
    //    {
    //        if (IsEmpty()) { throw new Exception("Invalid index, List is empty"); }
    //        if (index == 0)
    //        {
    //            return head.Data;
    //        }

    //        int currentIndex = 0;
    //        for (Node tempNode = head; tempNode != null; tempNode = tempNode.Next)
    //        {
    //            if (currentIndex == index)
    //            {
    //                return tempNode.Data;
    //            }
    //            else { currentIndex++; }
    //        }
    //        throw new Exception("Index outside of range");
    //    }

    //    public int Size()
    //    {
    //        if (IsEmpty()) {  return 0; }

    //        Node tempNode = head;
    //        int size = 1;
    //        while (tempNode.Next != null)
    //        {
    //            size++;
    //            tempNode = tempNode.Next;
    //        }
    //        return size;
    //    }
    //}
}
