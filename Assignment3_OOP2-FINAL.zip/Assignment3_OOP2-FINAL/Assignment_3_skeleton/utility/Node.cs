﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_3_skeleton.utility
{
    public class Node
    {
        object element;
        Node successor;

        public Node(object data, Node next)
        {
            this.element = data;
            this.successor = next;
        }

        public Node(object data)
        {
            Element = data;
        }

        public object Element { get => element; set => element = value; }
        public Node Successor { get => successor; set => successor = value; }
    }
}
