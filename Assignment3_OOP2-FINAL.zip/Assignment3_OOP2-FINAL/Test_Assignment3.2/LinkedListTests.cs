﻿using Assignment_3_skeleton;
using Assignment_3_skeleton.utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
/*using static System.Runtime.InteropServices.JavaScript.JSType;*/
namespace Test_Assignment_3
{
    public class LinkedListTests
    {
        private LinkedListADT linkedList;

        [SetUp]
        public void Setup()
        {
            // Create your concrete linked list class and assign to to linkedList.
            this.linkedList = new SLL();
        }

        [TearDown]
        public void TearDown()
        {
            this.linkedList.Clear();
        }

        //Test the linked list is empty.
        [Test]
        public void TestIsEmpty()
        {
            Assert.True(this.linkedList.IsEmpty());
            Assert.AreEqual(0, this.linkedList.Size());
        }

        //Tests appending elements to the linked list.
        [Test]
        public void TestAppendNode()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");


            /**
             * Linked list should now be:
             * 
             * a -> b -> c -> d
             */

            // Test the linked list is not empty.
            Assert.False(this.linkedList.IsEmpty());

            // Test the size is 4
            Assert.AreEqual(4, this.linkedList.Size());

            // Test the first node value is a
            Assert.AreEqual("a", this.linkedList.Retrieve(0));

            // Test the second node value is b
            Assert.AreEqual("b", this.linkedList.Retrieve(1));

            // Test the third node value is c
            Assert.AreEqual("c", this.linkedList.Retrieve(2));

            // Test the fourth node value is d
            Assert.AreEqual("d", this.linkedList.Retrieve(3));
        }

        //Tests prepending nodes to linked list.
        [Test]
        public void testPrependNodes()
        {
            this.linkedList.Prepend("a");
            this.linkedList.Prepend("b");
            this.linkedList.Prepend("c");
            this.linkedList.Prepend("d");

            /**
             * Linked list should now be:
             * 
             * d -> c -> b -> a
             */

            // Test the linked list is not empty.
            Assert.False(this.linkedList.IsEmpty());

            // Test the size is 4
            Assert.AreEqual(4, this.linkedList.Size());

            // Test the first node value is a
            Assert.AreEqual("d", this.linkedList.Retrieve(0));

            // Test the second node value is b
            Assert.AreEqual("c", this.linkedList.Retrieve(1));

            // Test the third node value is c
            Assert.AreEqual("b", this.linkedList.Retrieve(2));

            // Test the fourth node value is d
            Assert.AreEqual("a", this.linkedList.Retrieve(3));
        }

        //Tests inserting node at valid index.
        [Test]
        public void TestInsertNode()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");

            this.linkedList.Insert("e", 2);

            /**
             * Linked list should now be:
             * 
             * a -> b -> e -> c -> d
             */

            // Test the linked list is not empty.
            Assert.False(this.linkedList.IsEmpty());

            // Test the size is 4
            Assert.AreEqual(5, this.linkedList.Size());

            // Test the first node value is a
            Assert.AreEqual("a", this.linkedList.Retrieve(0));

            // Test the second node value is b
            Assert.AreEqual("b", this.linkedList.Retrieve(1));

            // Test the third node value is e
            Assert.AreEqual("e", this.linkedList.Retrieve(2));

            // Test the third node value is c
            Assert.AreEqual("c", this.linkedList.Retrieve(3));

            // Test the fourth node value is d
            Assert.AreEqual("d", this.linkedList.Retrieve(4));
        }

        //Tests replacing existing nodes data.
        [Test]
        public void TestReplaceNode()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");

            this.linkedList.Replace("e", 2);

            /**
             * Linked list should now be:
             * 
             * a -> b -> e -> d
             */

            // Test the linked list is not empty.
            Assert.False(this.linkedList.IsEmpty());

            // Test the size is 4
            Assert.AreEqual(4, this.linkedList.Size());

            // Test the first node value is a
            Assert.AreEqual("a", this.linkedList.Retrieve(0));

            // Test the second node value is b
            Assert.AreEqual("b", this.linkedList.Retrieve(1));

            // Test the third node value is e
            Assert.AreEqual("e", this.linkedList.Retrieve(2));

            // Test the fourth node value is d
            Assert.AreEqual("d", this.linkedList.Retrieve(3));
        }

        //Tests deleting node from linked list.
        [Test]
        public void TestDeleteNode()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");

            this.linkedList.Delete(2);

            /**
             * Linked list should now be:
             * 
             * a -> b -> d
             */

            // Test the linked list is not empty.
            Assert.False(this.linkedList.IsEmpty());

            // Test the size is 4
            Assert.AreEqual(3, this.linkedList.Size());

            // Test the first node value is a
            Assert.AreEqual("a", this.linkedList.Retrieve(0));

            // Test the second node value is b
            Assert.AreEqual("b", this.linkedList.Retrieve(1));

            // Test the fourth node value is d
            Assert.AreEqual("d", this.linkedList.Retrieve(2));
        }

        //Tests finding and retrieving node in linked list.
        [Test]
        public void TestFindNode()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");

            /**
             * Linked list should now be:
             * 
             * a -> b -> c -> d
             */

            bool contains = this.linkedList.Contains("b");
            Assert.True(contains);

            int index = this.linkedList.IndexOf("b");
            Assert.AreEqual(1, index);

            string value = (string)this.linkedList.Retrieve(1);
            Assert.AreEqual("b", value);
        }

        //-------------------------------------------------------------------------------------------------
        [Test] // find the first duplicate in the list
        public void TestFindDuplicates()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("b");
            this.linkedList.Append("d");
            //list is now a -> b -> b -> d

            bool same = false;

            for (int i = 0; i < this.linkedList.Size() - 1; i++)
            {
                object current = this.linkedList.Retrieve(i);// first item

                for (int j = i + 1; j < this.linkedList.Size(); j++) // rest of list after "first item"
                {
                    object comparison = this.linkedList.Retrieve(j);
                    if (current.Equals(comparison))
                    {
                        Console.WriteLine("First duplicate is: " + current);
                        same = true;
                        break; // exit comparison loop
                    }
                }

                if (same) //true
                {
                    break; // exit iteriating loop
                }
            }

            Assert.IsTrue(same);

        }

        [Test] // check the size of the list
        public void TestGetListSize()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");
            //list is now a --> d

            Assert.AreEqual(4, this.linkedList.Size()); // list has 4 items
        }

        [Test] // print the list and compare to expected outcome
        public void TestPrintList()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");
            //list is now a --> d

            Node current = this.linkedList.Head;

            string ListasString = ""; // entire list as one string to compare

            while (current != null)
            {
                ListasString += current.Element;
                current = current.Successor;
            }
            // string should be abcd

            string expected = "abcd";

            Assert.AreEqual(expected, ListasString);

        }

        [Test] // check if the end of the list has been deleted
        public void TestDeleteEndOfList()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");
            //list is now a --> d

            this.linkedList.RemoveTail(); // delete the last node

            // Test the size is 3
            Assert.AreEqual(3, this.linkedList.Size());

            // Test the first node value is a
            Assert.AreEqual("a", this.linkedList.Retrieve(0));

            // Test the second node value is b
            Assert.AreEqual("b", this.linkedList.Retrieve(1));

            // Test the third node value is e
            Assert.AreEqual("c", this.linkedList.Retrieve(2));
        }

        [Test] // check if the start of the list has been deleted
        public void TestDeleteBeginingOfList()
        {
            this.linkedList.Append("a");
            this.linkedList.Append("b");
            this.linkedList.Append("c");
            this.linkedList.Append("d");
            //list is now a --> d

            this.linkedList.RemoveHead(); // delete the first node

            // Test the size is 3
            Assert.AreEqual(3, this.linkedList.Size());

            // Test the first node value is a
            Assert.AreEqual("b", this.linkedList.Retrieve(0));

            // Test the second node value is b
            Assert.AreEqual("c", this.linkedList.Retrieve(1));

            // Test the third node value is e
            Assert.AreEqual("d", this.linkedList.Retrieve(2));
        }
    }
}

//namespace Test_Assignment_3_2
//{
//    public class LinkedListTests
//    {
//        private LinkedListADT linkedList;

//        [SetUp]
//        public void Setup()
//        {
//            // Create your concrete linked list class and assign to to linkedList.
//            this.linkedList = new SLL();
//        }

//        [TearDown]
//        public void TearDown()
//        {
//            this.linkedList.Clear();
//        }

//        //Test the linked list is empty.
//        [Test]
//        public void TestIsEmpty()
//        {
//            Assert.True(this.linkedList.IsEmpty());
//            Assert.AreEqual(0, this.linkedList.Size());
//        }

//        //Tests prepending nodes to linked list.
//        [Test]
//        public void testPrependNodes()
//        {
//            this.linkedList.Prepend("a");
//            this.linkedList.Prepend("b");
//            this.linkedList.Prepend("c");
//            this.linkedList.Prepend("d");

//            /**
//             * Linked list should now be:
//             * 
//             * d -> c -> b -> a
//             */

//            // Test the linked list is not empty.
//            Assert.False(this.linkedList.IsEmpty());

//            // Test the size is 4
//            Assert.AreEqual(4, this.linkedList.Size());

//            // Test the first node value is a
//            Assert.AreEqual("d", this.linkedList.Retrieve(0));

//            // Test the second node value is b
//            Assert.AreEqual("c", this.linkedList.Retrieve(1));

//            // Test the third node value is c
//            Assert.AreEqual("b", this.linkedList.Retrieve(2));

//            // Test the fourth node value is d
//            Assert.AreEqual("a", this.linkedList.Retrieve(3));
//        }

//        //Tests appending elements to the linked list.
//        [Test]
//        public void TestAppendNode()
//        {
//            this.linkedList.Append("a");
//            this.linkedList.Append("b");
//            this.linkedList.Append("c");
//            this.linkedList.Append("d");

//            /**
//             * Linked list should now be:
//             * 
//             * a -> b -> c -> d
//             */

//            // Test the linked list is not empty.
//            Assert.False(this.linkedList.IsEmpty());

//            // Test the size is 4
//            Assert.AreEqual(4, this.linkedList.Size());

//            // Test the first node value is a
//            Assert.AreEqual("a", this.linkedList.Retrieve(0));

//            // Test the second node value is b
//            Assert.AreEqual("b", this.linkedList.Retrieve(1));

//            // Test the third node value is c
//            Assert.AreEqual("c", this.linkedList.Retrieve(2));

//            // Test the fourth node value is d
//            Assert.AreEqual("d", this.linkedList.Retrieve(3));
//        }        

//        //Tests inserting node at valid index.
//        [Test]
//        public void TestInsertNode()
//        {
//            this.linkedList.Append("a");
//            this.linkedList.Append("b");
//            this.linkedList.Append("c");
//            this.linkedList.Append("d");

//            this.linkedList.Insert("e", 2);

//            /**
//             * Linked list should now be:
//             * 
//             * a -> b -> e -> c -> d
//             */

//            // Test the linked list is not empty.
//            Assert.False(this.linkedList.IsEmpty());

//            // Test the size is 4
//            Assert.AreEqual(5, this.linkedList.Size());

//            // Test the first node value is a
//            Assert.AreEqual("a", this.linkedList.Retrieve(0));

//            // Test the second node value is b
//            Assert.AreEqual("b", this.linkedList.Retrieve(1));

//            // Test the third node value is e
//            Assert.AreEqual("e", this.linkedList.Retrieve(2));

//            // Test the third node value is c
//            Assert.AreEqual("c", this.linkedList.Retrieve(3));

//            // Test the fourth node value is d
//            Assert.AreEqual("d", this.linkedList.Retrieve(4));
//        }

//        //Tests replacing existing nodes data.
//        [Test]
//        public void TestReplaceNode()
//        {
//            this.linkedList.Append("a");
//            this.linkedList.Append("b");
//            this.linkedList.Append("c");
//            this.linkedList.Append("d");

//            this.linkedList.Replace("e", 2);

//            /**
//             * Linked list should now be:
//             * 
//             * a -> b -> e -> d
//             */

//            // Test the linked list is not empty.
//            Assert.False(this.linkedList.IsEmpty());

//            // Test the size is 4
//            Assert.AreEqual(4, this.linkedList.Size());

//            // Test the first node value is a
//            Assert.AreEqual("a", this.linkedList.Retrieve(0));

//            // Test the second node value is b
//            Assert.AreEqual("b", this.linkedList.Retrieve(1));

//            // Test the third node value is e
//            Assert.AreEqual("e", this.linkedList.Retrieve(2));

//            // Test the fourth node value is d
//            Assert.AreEqual("d", this.linkedList.Retrieve(3));
//        }

//        //Tests deleting nodes from linked list.
//        // deletes middle -> deletes first -> deletes last
//        [Test]
//        public void TestDeleteNode()
//        {
//            this.linkedList.Append("a");
//            this.linkedList.Append("b");
//            this.linkedList.Append("c");
//            this.linkedList.Append("d");

//            // deleting middle node
//            this.linkedList.Delete(2);

//            /**
//             * Linked list should now be:
//             * 
//             * a -> b -> d
//             */

//            // Test the linked list is not empty.
//            Assert.False(this.linkedList.IsEmpty());

//            // Test the size is 3
//            Assert.AreEqual(3, this.linkedList.Size());

//            // Test the first node value is a
//            Assert.AreEqual("a", this.linkedList.Retrieve(0));

//            // Test the second node value is b
//            Assert.AreEqual("b", this.linkedList.Retrieve(1));

//            // Test the fourth node value is d
//            Assert.AreEqual("d", this.linkedList.Retrieve(2));

//            // ===================================================

//            // deleting first node
//            this.linkedList.Delete(0);
//            /**
//             * Linked list should now be:
//             * 
//             * b -> d
//             */

//            // Test the linked list is not empty.
//            Assert.False(this.linkedList.IsEmpty());

//            // Test the size is 2
//            Assert.AreEqual(2, this.linkedList.Size());

//            // Test the first node value is a
//            Assert.AreEqual("b", this.linkedList.Retrieve(0));

//            // Test the second node value is b
//            Assert.AreEqual("d", this.linkedList.Retrieve(1));

//            // ===================================================

//            // deleting last node
//            this.linkedList.Delete(1);
//            /**
//             * Linked list should now be:
//             * 
//             * b 
//             */

//            // Test the linked list is not empty.
//            Assert.False(this.linkedList.IsEmpty());

//            // Test the size is 1
//            Assert.AreEqual(1, this.linkedList.Size());

//            // Test the first node value is a
//            Assert.AreEqual("b", this.linkedList.Retrieve(0));
//        }

//        //Tests finding and retrieving node in linked list.
//        [Test]
//        public void TestFindNode()
//        {
//            this.linkedList.Append("a");
//            this.linkedList.Append("b");
//            this.linkedList.Append("c");
//            this.linkedList.Append("d");

//            /**
//             * Linked list should now be:
//             * 
//             * a -> b -> c -> d
//             */

//            bool contains = this.linkedList.Contains("b");
//            Assert.True(contains);

//            int index = this.linkedList.IndexOf("b");
//            Assert.AreEqual(1, index);

//            string value = (string)this.linkedList.Retrieve(1);
//            Assert.AreEqual("b", value);
//        }
//    }
//}
